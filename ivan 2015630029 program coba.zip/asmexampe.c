#include <stdio.h>

int main () {
	int a = 1;
	int b = 2;
	int c = 3;
	a += b;
	a = a + c;

	printf("value of A is %d\n", a);
	
	return 0;
}
